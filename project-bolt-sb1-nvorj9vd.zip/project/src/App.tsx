import React, { useState, useEffect, useCallback } from 'react';
import { Cookie } from 'lucide-react';
import CookieDisplay from './components/CookieDisplay';
import UpgradeShop from './components/UpgradeShop';
import Stats from './components/Stats';
import Achievements from './components/Achievements';
import GoldenCookie from './components/GoldenCookie';
import GameEffects from './components/GameEffects';
import { GameState, GoldenCookie as GoldenCookieType, GameEffect } from './types/game';
import { UPGRADES, ACHIEVEMENTS } from './data/gameData';

function App() {
  const [gameState, setGameState] = useState<GameState>({
    cookies: 0,
    totalCookies: 0,
    cookiesPerSecond: 0,
    clickPower: 1,
    upgrades: UPGRADES,
    achievements: ACHIEVEMENTS,
    totalClicks: 0,
    startTime: Date.now(),
    goldenCookieClicks: 0,
    prestige: 0,
    heavenlyChips: 0,
  });

  const [clickAnimations, setClickAnimations] = useState<Array<{ id: number; x: number; y: number; value: number }>>([]);
  const [goldenCookies, setGoldenCookies] = useState<GoldenCookieType[]>([]);
  const [gameEffects, setGameEffects] = useState<GameEffect[]>([]);
  const [clickMultiplier, setClickMultiplier] = useState(1);

  // Load game state from localStorage
  useEffect(() => {
    const savedState = localStorage.getItem('cookieClicker');
    if (savedState) {
      try {
        const parsed = JSON.parse(savedState);
        setGameState(prev => ({
          ...prev,
          ...parsed,
          upgrades: UPGRADES.map(upgrade => ({
            ...upgrade,
            count: parsed.upgrades?.find((u: any) => u.id === upgrade.id)?.count || 0,
          })),
          achievements: ACHIEVEMENTS.map(achievement => ({
            ...achievement,
            unlocked: parsed.achievements?.find((a: any) => a.id === achievement.id)?.unlocked || false,
          })),
          startTime: parsed.startTime || Date.now(),
        }));
      } catch (error) {
        console.error('Failed to load saved game:', error);
      }
    }
  }, []);

  // Save game state to localStorage
  useEffect(() => {
    const saveData = {
      ...gameState,
      achievements: gameState.achievements.map(a => ({ id: a.id, unlocked: a.unlocked })),
      upgrades: gameState.upgrades.map(u => ({ id: u.id, count: u.count })),
    };
    localStorage.setItem('cookieClicker', JSON.stringify(saveData));
  }, [gameState]);

  // Calculate cookies per second and click multiplier
  useEffect(() => {
    const baseCps = gameState.upgrades.reduce((total, upgrade) => total + (upgrade.cps * upgrade.count), 0);
    const effectMultiplier = gameEffects.reduce((mult, effect) => mult * effect.multiplier, 1);
    const finalCps = baseCps * effectMultiplier;
    
    setGameState(prev => ({ ...prev, cookiesPerSecond: finalCps }));
    
    // Update click multiplier based on effects
    const clickEffect = gameEffects.find(e => e.name.includes('Click'));
    setClickMultiplier(clickEffect ? clickEffect.multiplier : 1);
  }, [gameState.upgrades, gameEffects]);

  // Auto-generate cookies
  useEffect(() => {
    if (gameState.cookiesPerSecond > 0) {
      const interval = setInterval(() => {
        setGameState(prev => ({
          ...prev,
          cookies: prev.cookies + prev.cookiesPerSecond,
          totalCookies: prev.totalCookies + prev.cookiesPerSecond,
        }));
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [gameState.cookiesPerSecond]);

  // Check achievements
  useEffect(() => {
    setGameState(prev => ({
      ...prev,
      achievements: prev.achievements.map(achievement => {
        if (!achievement.unlocked && achievement.condition(prev)) {
          // Award achievement reward
          const reward = achievement.reward || 0;
          setTimeout(() => {
            setGameState(current => ({
              ...current,
              cookies: current.cookies + reward,
              totalCookies: current.totalCookies + reward,
            }));
          }, 100);
          
          return { ...achievement, unlocked: true };
        }
        return achievement;
      }),
    }));
  }, [gameState.totalCookies, gameState.totalClicks, gameState.cookiesPerSecond, gameState.goldenCookieClicks]);

  // Spawn golden cookies
  useEffect(() => {
    const spawnGoldenCookie = () => {
      if (gameState.totalCookies > 100 && Math.random() < 0.3) {
        const newGoldenCookie: GoldenCookieType = {
          id: Date.now(),
          x: Math.random() * 80 + 10,
          y: Math.random() * 80 + 10,
          type: Math.random() < 0.5 ? 'bonus' : Math.random() < 0.7 ? 'frenzy' : 'multiply',
          duration: 13000,
        };
        
        setGoldenCookies(prev => [...prev, newGoldenCookie]);
        
        // Remove golden cookie after duration
        setTimeout(() => {
          setGoldenCookies(prev => prev.filter(gc => gc.id !== newGoldenCookie.id));
        }, newGoldenCookie.duration);
      }
    };

    const interval = setInterval(spawnGoldenCookie, 30000 + Math.random() * 60000); // 30-90 seconds
    return () => clearInterval(interval);
  }, [gameState.totalCookies]);

  // Clean up expired effects
  useEffect(() => {
    const interval = setInterval(() => {
      setGameEffects(prev => prev.filter(effect => 
        Date.now() - effect.startTime < effect.duration
      ));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const handleCookieClick = useCallback((event: React.MouseEvent) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    const clickValue = gameState.clickPower * clickMultiplier;

    // Add click animation
    const animationId = Date.now();
    setClickAnimations(prev => [...prev, { id: animationId, x, y, value: clickValue }]);

    // Remove animation after delay
    setTimeout(() => {
      setClickAnimations(prev => prev.filter(anim => anim.id !== animationId));
    }, 1000);

    setGameState(prev => ({
      ...prev,
      cookies: prev.cookies + clickValue,
      totalCookies: prev.totalCookies + clickValue,
      totalClicks: prev.totalClicks + 1,
    }));
  }, [gameState.clickPower, clickMultiplier]);

  const handleUpgradePurchase = useCallback((upgradeId: string) => {
    setGameState(prev => {
      const upgrade = prev.upgrades.find(u => u.id === upgradeId);
      if (!upgrade) return prev;

      const cost = Math.floor(upgrade.baseCost * Math.pow(1.15, upgrade.count));
      if (prev.cookies < cost) return prev;

      return {
        ...prev,
        cookies: prev.cookies - cost,
        upgrades: prev.upgrades.map(u =>
          u.id === upgradeId ? { ...u, count: u.count + 1 } : u
        ),
      };
    });
  }, []);

  const handleGoldenCookieClick = useCallback((id: number) => {
    const goldenCookie = goldenCookies.find(gc => gc.id === id);
    if (!goldenCookie) return;

    setGoldenCookies(prev => prev.filter(gc => gc.id !== id));
    setGameState(prev => ({ ...prev, goldenCookieClicks: prev.goldenCookieClicks + 1 }));

    // Apply golden cookie effect
    switch (goldenCookie.type) {
      case 'bonus':
        const bonus = Math.max(gameState.cookies * 0.1, gameState.cookiesPerSecond * 60);
        setGameState(prev => ({
          ...prev,
          cookies: prev.cookies + bonus,
          totalCookies: prev.totalCookies + bonus,
        }));
        break;
      
      case 'frenzy':
        const frenzyEffect: GameEffect = {
          id: 'frenzy',
          name: 'Cookie Frenzy',
          multiplier: 7,
          duration: 77000,
          startTime: Date.now(),
        };
        setGameEffects(prev => [...prev.filter(e => e.id !== 'frenzy'), frenzyEffect]);
        break;
      
      case 'multiply':
        const clickEffect: GameEffect = {
          id: 'click_frenzy',
          name: 'Click Frenzy',
          multiplier: 777,
          duration: 13000,
          startTime: Date.now(),
        };
        setGameEffects(prev => [...prev.filter(e => e.id !== 'click_frenzy'), clickEffect]);
        break;
    }
  }, [goldenCookies, gameState.cookies, gameState.cookiesPerSecond]);

  const formatNumber = (num: number): string => {
    if (num >= 1e15) return (num / 1e15).toFixed(2) + ' quadrillion';
    if (num >= 1e12) return (num / 1e12).toFixed(2) + ' trillion';
    if (num >= 1e9) return (num / 1e9).toFixed(2) + ' billion';
    if (num >= 1e6) return (num / 1e6).toFixed(2) + ' million';
    if (num >= 1e3) return (num / 1e3).toFixed(1) + 'K';
    return Math.floor(num).toLocaleString();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-red-50 relative">
      {/* Golden cookies */}
      {goldenCookies.map(goldenCookie => (
        <GoldenCookie
          key={goldenCookie.id}
          goldenCookie={goldenCookie}
          onGoldenCookieClick={handleGoldenCookieClick}
        />
      ))}

      {/* Game effects */}
      <GameEffects effects={gameEffects} />

      <div className="container mx-auto px-4 py-8">
        <header className="text-center mb-8">
          <h1 className="text-5xl font-bold text-amber-800 mb-2 flex items-center justify-center gap-3">
            <Cookie className="w-12 h-12 text-amber-600" />
            Cookie Clicker
          </h1>
          <p className="text-amber-600 text-xl">The most addictive cookie game ever!</p>
          <div className="text-sm text-amber-500 mt-2">
            Playing for {Math.floor((Date.now() - gameState.startTime) / 60000)} minutes
          </div>
        </header>

        <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
          {/* Cookie Display */}
          <div className="xl:col-span-2">
            <CookieDisplay
              cookies={gameState.cookies}
              totalCookies={gameState.totalCookies}
              cookiesPerSecond={gameState.cookiesPerSecond}
              onCookieClick={handleCookieClick}
              clickAnimations={clickAnimations}
              formatNumber={formatNumber}
              clickMultiplier={clickMultiplier}
            />
          </div>

          {/* Right sidebar */}
          <div className="xl:col-span-2 space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-1 gap-6">
              {/* Upgrade Shop */}
              <UpgradeShop
                upgrades={gameState.upgrades}
                cookies={gameState.cookies}
                totalCookies={gameState.totalCookies}
                onUpgradePurchase={handleUpgradePurchase}
                formatNumber={formatNumber}
              />
              
              {/* Stats and Achievements */}
              <div className="space-y-6">
                <Stats
                  gameState={gameState}
                  formatNumber={formatNumber}
                />
                
                <Achievements
                  achievements={gameState.achievements}
                  formatNumber={formatNumber}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;