import React from 'react';
import { Sparkles } from 'lucide-react';
import { GoldenCookie as GoldenCookieType } from '../types/game';

interface GoldenCookieProps {
  goldenCookie: GoldenCookieType;
  onGoldenCookieClick: (id: number) => void;
}

const GoldenCookie: React.FC<GoldenCookieProps> = ({ goldenCookie, onGoldenCookieClick }) => {
  return (
    <button
      onClick={() => onGoldenCookieClick(goldenCookie.id)}
      className="fixed z-50 w-16 h-16 bg-gradient-to-br from-yellow-300 to-yellow-500 rounded-full shadow-2xl animate-pulse hover:scale-110 transition-transform cursor-pointer border-4 border-yellow-200"
      style={{
        left: `${goldenCookie.x}%`,
        top: `${goldenCookie.y}%`,
        animation: 'goldenPulse 2s infinite, goldenFloat 3s ease-in-out infinite',
      }}
    >
      <Sparkles className="w-8 h-8 text-yellow-100 mx-auto mt-2" />
      <style jsx>{`
        @keyframes goldenPulse {
          0%, 100% { transform: scale(1); box-shadow: 0 0 20px rgba(255, 215, 0, 0.8); }
          50% { transform: scale(1.1); box-shadow: 0 0 30px rgba(255, 215, 0, 1); }
        }
        @keyframes goldenFloat {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
      `}</style>
    </button>
  );
};

export default GoldenCookie;