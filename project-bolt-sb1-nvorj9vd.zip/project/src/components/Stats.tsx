import React from 'react';
import { BarChart3, Clock, Target } from 'lucide-react';
import { GameState } from '../types/game';

interface StatsProps {
  gameState: GameState;
  formatNumber: (num: number) => string;
}

const Stats: React.FC<StatsProps> = ({ gameState, formatNumber }) => {
  const totalUpgrades = gameState.upgrades.reduce((total, upgrade) => total + upgrade.count, 0);
  const totalCPS = gameState.upgrades.reduce((total, upgrade) => total + (upgrade.cps * upgrade.count), 0);

  return (
    <div className="bg-white rounded-2xl shadow-xl p-6">
      <div className="flex items-center gap-2 mb-4">
        <BarChart3 className="w-6 h-6 text-amber-600" />
        <h2 className="text-2xl font-bold text-amber-800">Statistics</h2>
      </div>

      <div className="space-y-4">
        <div className="flex items-center gap-3 p-3 bg-amber-50 rounded-lg">
          <Target className="w-5 h-5 text-amber-600" />
          <div>
            <p className="text-sm text-amber-600">Total Cookies Earned</p>
            <p className="font-bold text-amber-800">{formatNumber(gameState.totalCookies)}</p>
          </div>
        </div>

        <div className="flex items-center gap-3 p-3 bg-amber-50 rounded-lg">
          <Clock className="w-5 h-5 text-amber-600" />
          <div>
            <p className="text-sm text-amber-600">Cookies per Second</p>
            <p className="font-bold text-amber-800">{formatNumber(totalCPS)}</p>
          </div>
        </div>

        <div className="flex items-center gap-3 p-3 bg-amber-50 rounded-lg">
          <BarChart3 className="w-5 h-5 text-amber-600" />
          <div>
            <p className="text-sm text-amber-600">Total Upgrades</p>
            <p className="font-bold text-amber-800">{totalUpgrades}</p>
          </div>
        </div>

        <div className="pt-4 border-t border-amber-200">
          <h3 className="font-semibold text-amber-800 mb-2">Upgrade Breakdown</h3>
          <div className="space-y-2">
            {gameState.upgrades.filter(upgrade => upgrade.count > 0).map((upgrade) => {
              const IconComponent = upgrade.icon;
              return (
                <div key={upgrade.id} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <IconComponent className="w-4 h-4 text-amber-600" />
                    <span className="text-amber-700">{upgrade.name}</span>
                  </div>
                  <span className="font-mono text-amber-800">{upgrade.count}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Stats;