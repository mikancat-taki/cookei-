import React from 'react';
import { ShoppingCart, Lock, Star } from 'lucide-react';
import { Upgrade } from '../types/game';

interface UpgradeShopProps {
  upgrades: Upgrade[];
  cookies: number;
  totalCookies: number;
  onUpgradePurchase: (upgradeId: string) => void;
  formatNumber: (num: number) => string;
}

const UpgradeShop: React.FC<UpgradeShopProps> = ({
  upgrades,
  cookies,
  totalCookies,
  onUpgradePurchase,
  formatNumber,
}) => {
  const calculateCost = (upgrade: Upgrade): number => {
    return Math.floor(upgrade.baseCost * Math.pow(1.15, upgrade.count));
  };

  const isUnlocked = (upgrade: Upgrade): boolean => {
    return !upgrade.unlockCondition || totalCookies >= upgrade.unlockCondition;
  };

  const visibleUpgrades = upgrades.filter(upgrade => isUnlocked(upgrade));

  return (
    <div className="bg-white rounded-2xl shadow-xl p-6">
      <div className="flex items-center gap-2 mb-4">
        <ShoppingCart className="w-6 h-6 text-amber-600" />
        <h2 className="text-2xl font-bold text-amber-800">Store</h2>
      </div>

      <div className="space-y-3 max-h-96 overflow-y-auto">
        {visibleUpgrades.map((upgrade) => {
          const cost = calculateCost(upgrade);
          const canAfford = cookies >= cost;
          const IconComponent = upgrade.icon;
          const efficiency = upgrade.cps / cost * 1000000; // cookies per million spent

          return (
            <button
              key={upgrade.id}
              onClick={() => canAfford && onUpgradePurchase(upgrade.id)}
              disabled={!canAfford}
              className={`w-full p-4 rounded-xl border-2 transition-all duration-200 relative ${
                canAfford
                  ? 'border-amber-300 bg-amber-50 hover:bg-amber-100 hover:border-amber-400 transform hover:scale-102 hover:shadow-lg'
                  : 'border-gray-200 bg-gray-50 opacity-60 cursor-not-allowed'
              }`}
            >
              {/* Efficiency indicator */}
              {efficiency > 50 && canAfford && (
                <div className="absolute -top-2 -right-2 bg-green-500 text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
                  <Star className="w-3 h-3" />
                  Best Deal!
                </div>
              )}

              <div className="flex items-center gap-3">
                <div className={`p-3 rounded-lg ${
                  canAfford ? 'bg-amber-200' : 'bg-gray-200'
                }`}>
                  {canAfford ? (
                    <IconComponent className="w-6 h-6 text-amber-700" />
                  ) : (
                    <Lock className="w-6 h-6 text-gray-500" />
                  )}
                </div>
                
                <div className="flex-1 text-left">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="font-semibold text-amber-800">
                      {upgrade.name}
                    </h3>
                    <span className="text-sm font-mono bg-amber-200 px-2 py-1 rounded">
                      {upgrade.count}
                    </span>
                  </div>
                  <p className="text-sm text-amber-600 mb-2">
                    {upgrade.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="text-xs text-amber-500">
                      <div>{formatNumber(upgrade.cps)} cookies/sec</div>
                      <div className="text-xs opacity-75">
                        Total: {formatNumber(upgrade.cps * upgrade.count)}/sec
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`font-bold ${
                        canAfford ? 'text-amber-700' : 'text-gray-500'
                      }`}>
                        {formatNumber(cost)}
                      </div>
                      <div className="text-xs text-amber-500">cookies</div>
                    </div>
                  </div>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Locked upgrades preview */}
      {upgrades.some(u => !isUnlocked(u)) && (
        <div className="mt-4 pt-4 border-t border-amber-200">
          <h3 className="text-sm font-semibold text-amber-700 mb-2">Coming Soon...</h3>
          <div className="space-y-2">
            {upgrades.filter(u => !isUnlocked(u)).slice(0, 2).map((upgrade) => {
              const IconComponent = upgrade.icon;
              return (
                <div key={upgrade.id} className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg opacity-60">
                  <Lock className="w-4 h-4 text-gray-400" />
                  <div className="flex-1">
                    <div className="text-sm font-medium text-gray-600">{upgrade.name}</div>
                    <div className="text-xs text-gray-500">
                      Unlocks at {formatNumber(upgrade.unlockCondition!)} total cookies
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default UpgradeShop;