import React from 'react';
import { Zap, Clock } from 'lucide-react';
import { GameEffect } from '../types/game';

interface GameEffectsProps {
  effects: GameEffect[];
}

const GameEffects: React.FC<GameEffectsProps> = ({ effects }) => {
  if (effects.length === 0) return null;

  return (
    <div className="fixed top-4 right-4 z-40 space-y-2">
      {effects.map((effect) => {
        const remainingTime = Math.max(0, effect.duration - (Date.now() - effect.startTime));
        const progress = (remainingTime / effect.duration) * 100;
        
        return (
          <div
            key={effect.id}
            className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-2 rounded-lg shadow-lg animate-pulse"
          >
            <div className="flex items-center gap-2 mb-1">
              <Zap className="w-4 h-4" />
              <span className="font-bold text-sm">{effect.name}</span>
              <span className="text-xs">x{effect.multiplier}</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-3 h-3" />
              <div className="flex-1 bg-white/20 rounded-full h-1">
                <div
                  className="bg-white h-1 rounded-full transition-all duration-1000"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <span className="text-xs">{Math.ceil(remainingTime / 1000)}s</span>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default GameEffects;