import React from 'react';
import { Award, Lock } from 'lucide-react';
import { Achievement } from '../types/game';

interface AchievementsProps {
  achievements: Achievement[];
  formatNumber: (num: number) => string;
}

const Achievements: React.FC<AchievementsProps> = ({ achievements, formatNumber }) => {
  const unlockedAchievements = achievements.filter(a => a.unlocked);
  const totalAchievements = achievements.length;

  return (
    <div className="bg-white rounded-2xl shadow-xl p-6">
      <div className="flex items-center gap-2 mb-4">
        <Award className="w-6 h-6 text-amber-600" />
        <h2 className="text-2xl font-bold text-amber-800">Achievements</h2>
        <span className="ml-auto text-sm text-amber-600">
          {unlockedAchievements.length}/{totalAchievements}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-3 max-h-64 overflow-y-auto">
        {achievements.map((achievement) => {
          const IconComponent = achievement.icon;
          return (
            <div
              key={achievement.id}
              className={`p-3 rounded-lg border-2 transition-all ${
                achievement.unlocked
                  ? 'border-amber-300 bg-amber-50'
                  : 'border-gray-200 bg-gray-50 opacity-60'
              }`}
            >
              <div className="flex items-center gap-2 mb-2">
                <div className={`p-1 rounded ${
                  achievement.unlocked ? 'bg-amber-200' : 'bg-gray-200'
                }`}>
                  {achievement.unlocked ? (
                    <IconComponent className="w-4 h-4 text-amber-700" />
                  ) : (
                    <Lock className="w-4 h-4 text-gray-500" />
                  )}
                </div>
                <h3 className={`font-semibold text-sm ${
                  achievement.unlocked ? 'text-amber-800' : 'text-gray-500'
                }`}>
                  {achievement.name}
                </h3>
              </div>
              <p className={`text-xs ${
                achievement.unlocked ? 'text-amber-600' : 'text-gray-400'
              }`}>
                {achievement.description}
              </p>
              {achievement.reward && achievement.unlocked && (
                <p className="text-xs text-amber-500 mt-1">
                  Reward: {formatNumber(achievement.reward)} cookies
                </p>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Achievements;