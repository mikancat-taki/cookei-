import React from 'react';
import { Cookie, TrendingUp, Sparkles } from 'lucide-react';

interface CookieDisplayProps {
  cookies: number;
  totalCookies: number;
  cookiesPerSecond: number;
  onCookieClick: (event: React.MouseEvent) => void;
  clickAnimations: Array<{ id: number; x: number; y: number; value: number }>;
  formatNumber: (num: number) => string;
  clickMultiplier: number;
}

const CookieDisplay: React.FC<CookieDisplayProps> = ({
  cookies,
  totalCookies,
  cookiesPerSecond,
  onCookieClick,
  clickAnimations,
  formatNumber,
  clickMultiplier,
}) => {
  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 text-center relative overflow-hidden">
      {/* Background particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-amber-300 rounded-full opacity-30 animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 2}s`,
              animationDuration: `${2 + Math.random() * 2}s`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10">
        <div className="mb-6">
          <div className="text-4xl font-bold text-amber-800 mb-2 font-mono">
            {formatNumber(cookies)}
          </div>
          <div className="text-lg text-amber-600 mb-1">cookies</div>
          <div className="flex items-center justify-center gap-4 text-amber-600">
            <div className="flex items-center gap-1">
              <TrendingUp className="w-4 h-4" />
              <span className="font-mono">{formatNumber(cookiesPerSecond)}/sec</span>
            </div>
            <div className="text-sm">
              Total: <span className="font-mono">{formatNumber(totalCookies)}</span>
            </div>
          </div>
        </div>

        <div className="relative inline-block">
          <button
            onClick={onCookieClick}
            className="relative w-72 h-72 bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 rounded-full shadow-2xl transform transition-all duration-150 hover:scale-105 active:scale-95 focus:outline-none focus:ring-4 focus:ring-amber-300 group"
            style={{
              filter: 'drop-shadow(0 0 20px rgba(245, 158, 11, 0.5))',
            }}
          >
            <Cookie className="w-36 h-36 text-amber-100 mx-auto mt-18 group-hover:rotate-12 transition-transform duration-300" />
            
            {/* Cookie texture */}
            <div className="absolute inset-4 rounded-full bg-gradient-to-br from-amber-300 to-amber-500 opacity-30 blur-sm"></div>
            
            {/* Chocolate chips */}
            {[...Array(8)].map((_, i) => (
              <div
                key={i}
                className="absolute w-3 h-3 bg-amber-800 rounded-full opacity-60"
                style={{
                  left: `${30 + Math.random() * 40}%`,
                  top: `${30 + Math.random() * 40}%`,
                }}
              />
            ))}
            
            {/* Hover glow */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-yellow-300 to-amber-400 opacity-0 group-hover:opacity-40 transition-opacity blur-lg"></div>
            
            {/* Active pulse */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-yellow-200 to-amber-300 opacity-0 group-active:opacity-60 transition-opacity"></div>
          </button>

          {/* Click animations */}
          {clickAnimations.map((animation) => (
            <div
              key={animation.id}
              className="absolute pointer-events-none z-20"
              style={{
                left: animation.x,
                top: animation.y,
                transform: 'translate(-50%, -50%)',
                animation: 'floatUp 1s ease-out forwards',
              }}
            >
              <div className="text-2xl font-bold text-amber-600 flex items-center gap-1">
                +{formatNumber(animation.value)}
                {clickMultiplier > 1 && <Sparkles className="w-4 h-4 text-yellow-500" />}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 text-amber-700">
          <p className="text-lg font-semibold mb-2">Click the big cookie!</p>
          <p className="text-sm opacity-75">
            Each click gives you{' '}
            <span className="font-bold">
              {formatNumber(clickMultiplier)} cookie{clickMultiplier !== 1 ? 's' : ''}
            </span>
            {clickMultiplier > 1 && (
              <span className="text-yellow-600 ml-1">
                <Sparkles className="w-4 h-4 inline" />
              </span>
            )}
          </p>
        </div>
      </div>

      <style jsx>{`
        @keyframes floatUp {
          0% {
            opacity: 1;
            transform: translate(-50%, -50%) scale(1);
          }
          100% {
            opacity: 0;
            transform: translate(-50%, -150%) scale(1.2);
          }
        }
      `}</style>
    </div>
  );
};

export default CookieDisplay;