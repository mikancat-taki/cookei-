import { DivideIcon as LucideIcon } from 'lucide-react';

export interface Upgrade {
  id: string;
  name: string;
  description: string;
  icon: LucideIcon;
  baseCost: number;
  cps: number;
  count: number;
  unlockCondition?: number;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: LucideIcon;
  condition: (gameState: GameState) => boolean;
  unlocked: boolean;
  reward?: number;
}

export interface GameState {
  cookies: number;
  totalCookies: number;
  cookiesPerSecond: number;
  clickPower: number;
  upgrades: Upgrade[];
  achievements: Achievement[];
  totalClicks: number;
  startTime: number;
  goldenCookieClicks: number;
  prestige: number;
  heavenlyChips: number;
}

export interface GoldenCookie {
  id: number;
  x: number;
  y: number;
  type: 'bonus' | 'frenzy' | 'multiply';
  duration: number;
}

export interface GameEffect {
  id: string;
  name: string;
  multiplier: number;
  duration: number;
  startTime: number;
}